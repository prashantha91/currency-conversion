package com.neo.codechallenge.currencyconversion.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConversionResponseDataDto {
	
	private int id;
	private String fromCurrencyCode;
	private String fromCurrencyName;
	private String toCurrencyCode;
	private String toCurrencyName;
	private BigDecimal exchangeRate;

}
