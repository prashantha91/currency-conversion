package com.neo.codechallenge.currencyconversion.service;

import java.io.ByteArrayInputStream;

public interface CurrencyConvertService {
	
	public ByteArrayInputStream convertCurrency(String fromCurrency, String toCurrency, String amount);

}
