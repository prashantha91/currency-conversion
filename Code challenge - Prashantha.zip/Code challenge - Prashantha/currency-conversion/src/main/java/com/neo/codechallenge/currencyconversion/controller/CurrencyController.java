package com.neo.codechallenge.currencyconversion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.neo.codechallenge.currencyconversion.service.CurrencyConvertService;

@CrossOrigin("http://localhost:8000")
@RestController
@RequestMapping("/api")
public class CurrencyController {

	@Autowired
	private CurrencyConvertService currencyConvertService;

	// This is the main API(controller) in the project
	@GetMapping("/currency-conversion/{fromCurrency}/{toCurrency}/{amount}")
	public ResponseEntity<Resource> retrieveConvertCurrency(@PathVariable String fromCurrency,
			@PathVariable String toCurrency, @PathVariable String amount) {

		// convert cvs data to a input stream
		InputStreamResource file = new InputStreamResource(
				currencyConvertService.convertCurrency(fromCurrency, toCurrency, amount));
		String fileName = toCurrency + amount + ".csv";

		// return data as a file
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
				.contentType(MediaType.parseMediaType("application/csv")).body(file);
	}

}
