package com.neo.codechallenge.currencyconversion.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseDto {
	
	private int id;
	private String currencyCode;
	private String countryName;
	private String amount;
	private String path;

}
