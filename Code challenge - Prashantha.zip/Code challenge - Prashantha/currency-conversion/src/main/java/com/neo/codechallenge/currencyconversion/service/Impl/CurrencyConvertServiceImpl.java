package com.neo.codechallenge.currencyconversion.service.Impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.neo.codechallenge.currencyconversion.dto.CSVHelper;
import com.neo.codechallenge.currencyconversion.dto.ConversionResponseDataDto;
import com.neo.codechallenge.currencyconversion.dto.ResponseDto;
import com.neo.codechallenge.currencyconversion.service.CurrencyConvertService;

@Service
public class CurrencyConvertServiceImpl implements CurrencyConvertService {

	@Override
	public ByteArrayInputStream convertCurrency(String fromCurrency, String toCurrency, String amount) {
		// API end point to retrieve currency conversion data
		String uri = "https://api-coding-challenge.neofinancial.com/currency-conversion?seed=22424";
		// Rest template object for data retrieval
		RestTemplate restTemplate = new RestTemplate();
		List<ResponseDto> resList = new ArrayList<>();
		// List of convert currency objects
		ConversionResponseDataDto dtoList[] = restTemplate.getForObject(uri, ConversionResponseDataDto[].class);
		if(dtoList.length > 0) {
			for(ConversionResponseDataDto dto: dtoList) {
				if(dto.getFromCurrencyCode().equals(fromCurrency) && dto.getToCurrencyCode().equals(toCurrency)) {
					// Map data to CSV file
					ResponseDto response = new ResponseDto();
					response.setCountryName(dto.getToCurrencyName());
					response.setCurrencyCode(toCurrency);
					response.setPath(fromCurrency+"|"+toCurrency);
					BigDecimal realAmount = new BigDecimal(amount).multiply(dto.getExchangeRate());
					response.setAmount(realAmount.toString());
					resList.add(response);
				}
				if(dto.getToCurrencyCode().equals(toCurrency)) {
					if(dto.getFromCurrencyCode().equals(fromCurrency) && dto.getToCurrencyCode().equals(toCurrency)) {
						
					}
					
				}
			}
		}
		ByteArrayInputStream in = CSVHelper.currencyDataToCSV(resList);
	    return in;
	}

}
